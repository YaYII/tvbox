//按钮集合
var butList = new Array();
//行集合
var rowList = new Array();
//行
var row = 0;
//焦点
var focusIndex = 0;
//签到
var toDaySign;
//确定
function key_enter_event() {
	if(row == 2){
		hideDiv("sign-box");
		row = 1;
		setFocusSrc();
	}else if (row ==1 && focusIndex==0) {//领取
		if ("true"==toDaySign) {
			remFocusSrc();
			row = 2;
			$("sign-text").innerHTML = "今天您已经签过到了哦！";
			showDiv("sign-box");
		}else {
			SavePv(domain, user, productID, rowList[row][focusIndex].gameId, visitType, rowList[row][focusIndex].id, state);
			window.location.href = rowList[row][focusIndex].enterUrl;
		}
	} else {
		SavePv(domain, user, productID, rowList[row][focusIndex].gameId, visitType, rowList[row][focusIndex].id, state);
		window.location.href = rowList[row][focusIndex].enterUrl;
	}
}

//上
function key_up_event() {
	switch(row) {
    case 1:
    	remFocusSrc();
        row = 0;
        focusIndex = 0;
        setFocusSrc();
        break;
	 }
}

//下
function key_down_event() {
	 switch(row) {
     case 0:
         remFocusSrc();
         row = 1;
         focusIndex = 0;
         setFocusSrc();
         break;
	 }
}

//左
function key_left_event() {
    switch(row) {
	    case 0:
			remFocusSrc();
			if (focusIndex > 0) {
				focusIndex--;
			}
			setFocusSrc();
			break;
        case 1:
            if(focusIndex > 0) {
            	remFocusSrc();
                focusIndex--;
                setFocusSrc();
            }
            break;
    }
}

//右
function key_right_event() {
    switch(row) {
    case 0:
    	remFocusSrc();
		if(focusIndex < 2){
			focusIndex ++;
		}
		setFocusSrc();
	break;
        case 1:
        	remFocusSrc();
            if(focusIndex < rowList[row].length-1) {
            	focusIndex++;
            }
            setFocusSrc();
            break;
    }
}