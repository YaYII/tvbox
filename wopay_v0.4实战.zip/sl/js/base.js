/**
 * 通用JS库
 * @author tanzhuo
 * @date 2016年9月10日
 */
var KEY_BACK         = 1280;    // 返回/删除
var KEY_BACK2        = 8;     // 返回2
var KEY_ENTER        = 13;    // 确定
var KEY_PAGE_UP      = 33;    // 上页
var KEY_PAGE_DOWN    = 34;    // 下页
var KEY_LEFT         = 37;    // 左
var KEY_UP           = 38;    // 上
var KEY_RIGHT        = 39;    // 右
var KEY_DOWN         = 40;    // 下
var KEY_0            = 48;    // 0       
var KEY_1            = 0x0031;    // 1
var KEY_2            = 0x0032;    // 2
var KEY_3            = 0x0033;    // 3
var KEY_4            = 0x0034;    // 4
var KEY_5            = 0x0035;    // 5
var KEY_6            = 0x0036;    // 6 
var KEY_7            = 0x0037;    // 7
var KEY_8            = 0x0038;    // 8
var KEY_9            = 0x0039;    // 9
var KEY_VOL_UP       = 259;       // Vol+，音量加
var KEY_VOL_DOWN     = 260;       // Vol-，音量减
var KEY_MUTE         = 261;       // Mute，静音
var KEY_TRACK        = 1060;      // Audio Track，切换音轨
var KEY_PLAY_PAUSE   = 263;       // >||，播放，暂停
var KEY_FAST_FORWARD = 0x0108;    // >> ，快进
var KEY_FAST_REWIND  = 0x0109;    // << ，快退
var KEY_RED          = 0x0113;    // 红色键
var KEY_GREEN        = 0x0114;    // 绿色键
var KEY_YELLOW       = 0x0115;    // 黄色键
var KEY_BLUE         = 0x0116;    // 蓝色键
//视频属性
var EVENT_MEDIA_END  = 18;   		// 视频播放结束 只做一件事情:循环播放视频  
var EVENT_MEDIA_ERROR= 116			// 视频播放错误
var domain,productID,user,gameId,isorder,visitType,state;
var start_time = new Date();	

// 常用函数
function $(id){return document.getElementById(id);}
function S(id){G(id).style.visibility = 'visible';}
function H(id){G(id).style.visibility = 'hidden';}
// 返回IPTV门户或者来源地址
function goIptvPortal(){
    top.location.href=Authentication.CTCGetConfig('EPGDomain');
}
/** 按键处理 */
//document.onkeypress = function(e) {
document.onkeypress = function(e) {
	e = e || window.event;
	var keyCode = e.which || e.keyCode;
	keyEventHandler(keyCode);
	// 视频循环播放
    if (keyCode == 0x0300) { 
        keyCode =  eval("oEvent = " + Utility.getEvent()).type;
        if (keyCode == "EVENT_MEDIA_END" || keyCode=='EVENT_MEDIA_ERROR'){
            Cycle();
        }
 	}
	//return false;
};
/**
 * 按键事件
 * @param keyCode
 * @returns
 */
function keyEventHandler(keyCode) {
	switch(keyCode) {
		case KEY_BACK:
			key_back_event();
			break;
		case KEY_BACK2:
			key_back_event();
			break;
		case KEY_ENTER:
			key_enter_event();
			break;
		case KEY_LEFT:
			key_left_event();
			break;
		case KEY_UP:
			key_up_event();
			break;
		case KEY_RIGHT:
			key_right_event();
			break;
		case KEY_DOWN:
			key_down_event();
			break;
		case KEY_0:
			key_back_event();
			break;
		case KEY_1:
		case KEY_2:
		case KEY_3:
		case KEY_4:
		case KEY_5:
		case KEY_6:
		case KEY_7:
		case KEY_8:
		case KEY_9:
			setKey(keyCode-48);
			checkPwd();
			break;
		case KEY_VOL_UP:
			key_volup_event();
			break;
		case KEY_VOL_DOWN:
			key_voldown_event();
			break;
		case KEY_MUTE:
			key_mute_event();
			break;
		case KEY_TRACK:		//切换左声道右声道.
			key_track_event();
			break;
		case KEY_PLAY_PAUSE:
			key_playorpurse_event();
			break;
		case EVENT_MEDIA_END: // 循环播放视频
			Cycle();
			break;
		case EVENT_MEDIA_ERROR:
			Cycle();
			break;
		default:
			break;
	}
}
//设置图片内容
function setImgSrc(btnid, imgurl) {
	$(btnid).src = imgurl;
}

//设置div里图片内容
function setDivImgSrc(btnid, imgurl) {
	$(btnid).getElementsByTagName("img")[0].src = imgurl;
}

//去掉div里图片内容
function remDivImgSrc(btnid) {
	$(btnid).getElementsByTagName("img")[0].src = "";
}

//隐藏DIV
function hideDiv(btnid) {
	$(btnid).style.display = "none";
}

//显示
function showDiv(btnid) {
	$(btnid).style.display = "block";
}

//设置DIV下焦点图片
function setFocusDivSrc() {
	$(rowList[row][focusIndex].id).getElementsByTagName("img")[0].src = rowList[row][focusIndex].src2;
}

//去掉DIV下焦点图片
function remFocusDivSrc() {
	$(rowList[row][focusIndex].id).getElementsByTagName("img")[0].src = rowList[row][focusIndex].src1;
}

//设置焦点图片
function setFocusSrc() {
	$(rowList[row][focusIndex].id).src = rowList[row][focusIndex].src2;
}

//去掉焦点图片
function remFocusSrc() {
	$(rowList[row][focusIndex].id).src = rowList[row][focusIndex].src1;
}

//设置背景框(选中框)
function setFocusBg() {
	$(rowList[row][focusIndex].id).style.backgroundImage = "url(" + rowList[row][focusIndex].src2 + ")";
}
//设置背景框(去掉选中框)
function remFocusDivBg() {
	$(rowList[row][focusIndex].id).style.backgroundImage = "url(" + rowList[row][focusIndex].src1 + ")";
}

//去掉背景框(选中框)
function remFocusBg() {
	$(rowList[row][focusIndex].id).style.backgroundImage = "none";
}
//设置div内容
function setDivText(btnid, text) {
	$(btnid).getElementsByTagName("div")[0].innerHTML = text;
}
//声明按钮
function but(id, src1, src2, enterUrl, gameId) {
	this.id = id;
	this.src1 = src1;
	this.src2 = src2;
	this.enterUrl = enterUrl;
	this.gameId = gameId;
}

//初始焦点按钮
function initFocusBut(row, focusIndex) {
	remFocusSrc();
	this.row = row;
	this.focusIndex = focusIndex;
	setFocusSrc();
}

//添加按钮数据
function addButData(id, src1, src2, enterUrl, gameId) {
    butList.push(new but(id, src1, src2, enterUrl, gameId));
}

//添加键值保存进Cookie方法
function setKey(k) {
	pval = getCookie('pwd');
	if(pval != null && pval != "") {
		pval += k;
		setCookie('pwd', pval, 1);
	} else {
		setCookie('pwd', k, 1);
	}
}

//检测密码
function checkPwd() {
	pval = getCookie('pwd');
	if(pval.length == 4) {
		if(pval == "4788") {
			deleteCookie('pwd');
			window.location.href = "http://183.60.27.91:8080/test_test.html?user="
				+ getCookie('user') 
				+ "&userID=" + getCookie('userID')
				+ "&zyUserToken=" + getCookie('zyUserToken')
				+ "&stbType=" + getCookie('stbType')
				+ "&enterURL=" + getCookie('enterURL');
		}
	} else if(pval.length > 4) {
		deleteCookie('pwd');
	}
}

//cookie 的名称、值以及过期天数。
function setCookie(c_name, value, expiredays) {
	var exdate = new Date();
	exdate.setDate(exdate.getDate() + expiredays);
	document.cookie = c_name + "=" + escape(value) +
	((expiredays == null) ? "" : ";expires=" + exdate.toGMTString())+";path=/";
}

//返回Cookie(值或空字符串)
function getCookie(c_name) {
	if(document.cookie.length > 0) {
		c_start = document.cookie.indexOf(c_name + "=");
		if(c_start != -1) {
			c_start = c_start + c_name.length + 1;
			c_end = document.cookie.indexOf(";", c_start);
			if(c_end == -1) {
				c_end = document.cookie.length;
			}
			return unescape(document.cookie.substring(c_start, c_end).replace(/\"/g, ""));
		}
	}
	return ""
}

// 删除 Cookie
function deleteCookie(name) {
	setCookie(name, "", -1);
}

//保存PV
function SavePv(pv_url, userid, productId, gameid, visitType, point, state) {
	this.domain=pv_url;
	this.user=userid;
	this.productID=productId;
	this.gameId=gameid;
	this.isorder=getCookie("isVip");
	this.visitType=visitType;
	this.state=state;
	//page 
	var c_url = window.location.href;
	if (c_url.indexOf("?")>-1) {
		c_url=c_url.substring(0, c_url.indexOf("?"));
	} 
	var refer_url = document.referrer;
	if (refer_url.indexOf("?")>-1) {
		refer_url=refer_url.substring(0, refer_url.indexOf("?"));
	} 
	//c_url = c_url.replace(/\&/g, "$");
    //refer_url = refer_url.replace(/\&/g, "$");
	//time
	var onlinetimes=time_erence();
	//stbtype
	var stbtype=getCookie("stbType");
	
	var jsonObj = {
		"userid": user,
		"stbtype": stbtype,
		"productId": productID,
		"gameid": gameid,
		"isorder": isorder,
		"visitType": visitType,
		"currentpage": c_url,
		"point": point,
		"fromtype": refer_url,
		"onlinetimes": onlinetimes,
		"state": state
	};

	var jStr = "{";

	for(var item in jsonObj){
        jStr += "\""+item+"\":\""+jsonObj[item]+"\",";
    }
	jStr += "\"t\":\"\"}";

	var fullurl = domain + "?params=" + escape(jStr);
	//var img = new Image();
	//img.src = fullurl;
	try {
		var img = document.createElement('img');
		img.src = fullurl;
		img.style.visibility = 'hidden';
		document.body.appendChild(img);
	} catch (e) {}
}
//保存风车乐园数据统计
function SavePvFcly(pv_url, userid, productId, gameid, visitType, point, state, isorder) {
	this.domain=pv_url;
	this.user=userid;
	this.productID=productId;
	this.gameId=gameid;
	this.isorder=isorder;
	this.visitType=visitType;
	this.state=state;
	//page 
	var c_url = window.location.href;
	if (c_url.indexOf("?")>-1) {
		c_url=c_url.substring(0, c_url.indexOf("?"));
	} 
	var refer_url = document.referrer;
	if (refer_url.indexOf("?")>-1) {
		refer_url=refer_url.substring(0, refer_url.indexOf("?"));
	} 
	//c_url = c_url.replace(/\&/g, "$");
	//refer_url = refer_url.replace(/\&/g, "$");
	//time
	var onlinetimes=time_erence();
	//stbtype
	var stbtype=getCookie("stbType");
	
	var jsonObj = {
			"userid": user,
			"stbtype": stbtype,
			"productId": productID,
			"gameid": gameid,
			"isorder": isorder,
			"visitType": visitType,
			"currentpage": c_url,
			"point": point,
			"fromtype": refer_url,
			"onlinetimes": onlinetimes,
			"state": state
	};
	
	var jStr = "{";
	
	for(var item in jsonObj){
		jStr += "\""+item+"\":\""+jsonObj[item]+"\",";
	}
	jStr += "\"t\":\"\"}";
	
	var fullurl = domain + "?params=" + escape(jStr);
	//var img = new Image();
	//img.src = fullurl;
	try {
		var img = document.createElement('img');
		img.src = fullurl;
		img.style.visibility = 'hidden';
		document.body.appendChild(img);
	} catch (e) {}
}
//保存payPV
function SavePayPv(pv_url, userid, productId, gameid, ordertype,orderfailcode) {
	this.domain=pv_url;
	this.user=userid;
	this.productID=productId;
	this.gameId=gameid;
	this.visitType=ordertype;
	this.state=orderfailcode;
	//page 
	var c_url = window.location.href;
	if (c_url.indexOf("?")>-1) {
		c_url=c_url.substring(0, c_url.indexOf("?"));
	} 
	var refer_url = document.referrer;
	if (refer_url.indexOf("?")>-1) {
		refer_url=refer_url.substring(0, refer_url.indexOf("?"));
	} 
	//c_url = c_url.replace(/\&/g, "$");
    //refer_url = refer_url.replace(/\&/g, "$");
	//time
	var onlinetimes=time_erence();
	//stbtype
	var stbtype=getCookie("stbType");
	
	var jsonObj = {
		"userid": user,
		"productId": productID,
		"gameid": gameid,
		"ordertype": visitType,
		"currentpage": c_url,
		"fromtype": refer_url,
		"orderfailcode": state
	};

	var jStr = "{";

	for(var item in jsonObj){
        jStr += "\""+item+"\":\""+jsonObj[item]+"\",";
    }
	jStr += "\"t\":\"\"}";

	var fullurl = domain + "?params=" + escape(jStr);
	//var img = new Image();
	//img.src = fullurl;
	try {
		var img = document.createElement('img');
		img.src = fullurl;
		img.style.visibility = 'hidden';
		document.body.appendChild(img);
	} catch (e) {}
}

//time start
function time_erence(){
	var tim = new class_time_difference();
 	var time = tim.time_difference(start_time);
 	return time;
}
function reset_date(){
	var tim = new class_time_difference();
	tim.resetd_date();
}

function class_time_difference() {
	this.resetd_date = function(){
		start_time = new Date();
	};
	this.time_difference = function(date){
		var end_datatime = new Date();   
		var ms=end_datatime.getTime()-date.getTime()  
		var seconds=Math.floor(ms/1000);  
		return  seconds;
	};
}
//time end


//ajax获取防沉迷可用时长  lisb 2017-07-13
function antiAddictionAjax(){
	var xmlhttp;
	if (window.XMLHttpRequest)
	{
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
			if(xmlhttp.responseText <= 0){
				antiAddiction_back();
			}else{
				document.getElementById("myDiv").innerHTML=xmlhttp.responseText;
				setTimeout(antiAddictionAjax, 2000);
			}
		}
	}
	xmlhttp.open("GET",antiAddictionUrl,true);
	xmlhttp.send();
}